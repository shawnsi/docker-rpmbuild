#!/usr/bin/env python

"""Docker rpmbuild.

Usage:
    docker-packager build [--spec=<file>] [--source=<tarball>] <image>

Options:
    -h --help           Show this screen.
    --source=<tarball>  Tarball containing package sources.
    --spec=<file>       RPM Spec file to build.

"""

import os.path
import shutil
import sys
import tempfile
from subprocess import check_call

from docopt import docopt
import docker

client = docker.Client()

template = """
FROM %s

RUN yum -y install rpmdevtools yum-utils
RUN rpmdev-setuptree

ADD $SPEC /rpmbuild/SPECS/
ADD $SOURCE /rpmbuild/SOURCES
RUN yum-builddep -y /rpmbuild/SPECS/$SPEC
RUN chown root:root /rpmbuild/SPECS/$SPEC /rpmbuild/SOURCES/$SOURCE
"""

class PackagerException(Exception):
    pass

class Packager(object):

    def __init__(self, image):
        self.image = image

    def __enter__(self):
        self.context = tempfile.mkdtemp()
        return self

    def __exit__(self, type, value, traceback):
        shutil.rmtree(self.temp)

    def __str__(self):
        return self.image

    def prepare_context(self, source, spec):
        shutil.copy(self.source, self.context)
        shutil.copy(self.spec, self.context)
        self.create_dockerfile(source, spec)

    def create_dockerfile(self, source, spec):
        dockerfile = template % (self.image, source, spec)
        with open(os.path.join(self.context, 'Dockerfile'), 'w') as f:
            f.write(dockerfile)

    def build(self, source, spec):
        self.prepare_context(source, spec)
        self.image, logs = client.build(self.context)
        print logs

        if not self.image:
            raise PackagerException

        self.container = client.create_container(self.image,
                'rpmbuild -ba %s' % os.path.join('/rpmbuild/SPECS', spec))
        client.start(self.container)
        client.wait(self.container)

        # Hack until https://github.com/dotcloud/docker-py/pull/105 is merged
        check_call(['docker', 'logs', self.container['Id']])
    

def main():
    args = docopt(__doc__, version='Docker Packager 0.0.1')

    if args['build']:
        try:
            with Packager(args['<image>']) as p:
                p.build(args['--spec'], args['--source'])

        except PackagerException:
            print >> sys.stderr, 'Container build failed!'
            sys.exit(1)

if __name__ == '__main__':
    main()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

